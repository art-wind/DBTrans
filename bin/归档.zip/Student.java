
public class Student {
	private String registno;
	private String name;
	private String kdno;
	private int kcno;
	private int ccno;
	private int seat;
	Student(){
		
	}
	public String getRegistno() {
		return registno;
	}
	public void setRegistno(String registno) {
		this.registno = registno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getKdno() {
		return kdno;
	}
	public void setKdno(String kdno) {
		this.kdno = kdno;
	}
	public int getKcno() {
		return kcno;
	}
	public void setKcno(int kcno) {
		this.kcno = kcno;
	}
	public int getCcno() {
		return ccno;
	}
	public void setCcno(int ccno) {
		this.ccno = ccno;
	}
	public int getSeat() {
		return seat;
	}
	public void setSeat(int seat) {
		this.seat = seat;
	}
	
}
